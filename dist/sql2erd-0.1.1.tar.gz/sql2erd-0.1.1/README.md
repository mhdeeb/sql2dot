Transforms a .sql file of CREATE TABLE statments into an ERD using Graphviz
